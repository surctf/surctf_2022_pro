package constant

var (
	CHAT_ID = int64(-875674057)
)
