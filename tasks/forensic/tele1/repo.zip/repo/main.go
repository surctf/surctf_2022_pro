package main

import (
	tele "gopkg.in/telebot.v3"
	"log"
	"os"
	"time"

	"scambot/handlers"
)

func main() {
	token, _ := os.ReadFile("token")
	pref := tele.Settings{
		Token:  string(token),
		Poller: &tele.LongPoller{Timeout: 10 * time.Second},
	}

	b, err := tele.NewBot(pref)
	if err != nil {
		log.Fatal(err)
		return
	}
	b.Handle("/start", handlers.StartHandler)
	b.Handle("/flag", handlers.FlagHandler)

	log.Print("Starting bot...")
	b.Start()
}
